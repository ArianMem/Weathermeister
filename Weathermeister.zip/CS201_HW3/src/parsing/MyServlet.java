package parsing;

import java.io.FileNotFoundException;
import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/MyServlet")
public class MyServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    @SuppressWarnings("unused")
    
	private static FileIO fio;
    /**
     * @throws IOException 
     * @throws FileNotFoundException 
     * @throws FormatException 
     * @see HttpServlet#HttpServlet()
     */
	
    public MyServlet() throws FormatException, FileNotFoundException, IOException {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.getWriter().append("Error: City Not Found");
		
		// Display All
		if (request.getParameter("displayAll") != null) {
			request.setAttribute("cities", FileIO.getCities());
			RequestDispatcher rd = request.getRequestDispatcher("all.jsp");
			rd.forward(request, response);
			return;
		}
		
		// search for a city using name
		else if(request.getParameter("citySearch") != null && request.getParameter("citySearch").trim().length() != 0) {
			String city = request.getParameter("citySearch");
			boolean found = false;
			for (City i : FileIO.getCities()) {
				if (city.trim().equalsIgnoreCase(i.getName())) {
					request.setAttribute("searchedCity", i);
					found = true;
				}
			}
			if (!found) {
				RequestDispatcher rd = request.getRequestDispatcher("failure.html");
				rd.forward(request, response);
				return;
			}
			
			RequestDispatcher rd = request.getRequestDispatcher("results.jsp");
			rd.forward(request, response);
			return;
		}
		
		// search for a city using latitude and longitude
		else if (request.getParameter("latSearch") != null && request.getParameter("longSearch") != null ) {
			String lat = request.getParameter("latSearch");
			String lon = request.getParameter("longSearch");
			if (lat.isEmpty() || lon.isEmpty()) {
				RequestDispatcher rd = request.getRequestDispatcher("failure.html");
				rd.forward(request, response);
				return;
			}
			try {
				Double latDouble = Double.parseDouble(lat);
				Double lonDouble = Double.parseDouble(lon);
				boolean found = false;
				for (City i : FileIO.getCities()) {
					if (latDouble == i.getLatitude() && lonDouble == i.getLongitude()) {
						request.setAttribute("searchedCity", i);
						found = true;
					}
				}
				if (!found) {
					RequestDispatcher rd = request.getRequestDispatcher("failure.html");
					rd.forward(request, response);
					return;
				}
				RequestDispatcher rd = request.getRequestDispatcher("results.jsp");
				rd.forward(request, response);
				return;
			}
			catch (NumberFormatException nfe) {
				RequestDispatcher rd = request.getRequestDispatcher("failure.html");
				rd.forward(request, response);
				return;
			}
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}
}

package parsing;

import java.sql.*;

public class SQLCON {
	
	public SQLCON() {
		// DEFAULT CONSTRUCTOR
	}
	
	/* Inserts user into the database */
	public void insertUser(String user, String pw, Connection con) {
		try {
			PreparedStatement ps = con.prepareStatement("INSERT INTO User values (? , ?)");	

			ps.setString(1, user);
			ps.setString(2, pw);
		    ps.executeUpdate();
		} 
		catch (SQLException e) {
			e.printStackTrace();
		}

	}
	
	/* Checking if both username + corresponding password exist */
	public boolean checkReg(String user, String pw, Connection con) throws SQLException {
		try {
			PreparedStatement ps = con.prepareStatement("SELECT * FROM User WHERE Username=? AND Password=?");		
			ps.setString(1, user);
			ps.setString(2, pw);
			ResultSet rs = ps.executeQuery();
			String pass="";
			while (rs.next()) {
				pass = rs.getString("pass");
				if(pass.contentEquals(pw)) {
					return true;
				}
			}
		}
		
		catch(SQLException e){
			e.printStackTrace();
		}
		return false;
	}
	
	/* Just checks for the username and see if it exists */
	public boolean checkUserExists(String user, Connection con) {
		try {
			PreparedStatement ps;
			ps = con.prepareStatement("SELECT * FROM User WHERE Username = ?");
			ps.setString(1, user);
			ResultSet rs = ps.executeQuery();
			if(rs.first()) {
				return true;
			}
		}
		catch(SQLException e){
			e.printStackTrace();
		}
		return false;
	}
}
